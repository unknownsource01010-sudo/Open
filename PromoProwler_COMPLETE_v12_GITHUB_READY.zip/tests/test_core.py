import unittest
from core import clean_codes, contains_challenge, normalize_offer, sort_offers
from promo_engine import detect_platform

class CoreTests(unittest.TestCase):
    def test_codes(self):
        self.assertEqual(clean_codes(["save20 SAVE20,free_ship bad!"]),["SAVE20","FREE_SHIP"])
    def test_challenge(self):
        self.assertTrue(contains_challenge("Please verify you are human"))
        self.assertFalse(contains_challenge("Welcome to our cart"))
    def test_offer_truthfulness(self):
        x=normalize_offer("Store","Thing","https://x",10,2,None)
        self.assertFalse(x["complete"]); self.assertEqual(x["known_total"],12.0); self.assertIsNone(x["total"])
        y=normalize_offer("Store","Thing","https://x",10,2,1)
        self.assertTrue(y["complete"]); self.assertEqual(y["total"],13.0)
    def test_complete_first(self):
        a=normalize_offer("A","x","x",5,0,None)
        b=normalize_offer("B","x","x",9,0,0)
        self.assertEqual(sort_offers([a,b])[0]["merchant"],"B")
    def test_platform(self):
        self.assertEqual(detect_platform("<script src='cdn.shopify.com/a.js'></script>","https://x/products/y"),"shopify")
        self.assertEqual(detect_platform("<body class='woocommerce-cart'>","https://x/cart"),"woocommerce")

if __name__=="__main__": unittest.main()
