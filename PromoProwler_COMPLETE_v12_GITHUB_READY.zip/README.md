# PromoProwler v11 — GitHub Pages + Live Worker

What changed:
- Live eBay Browse API adapter with OAuth client-credentials token handling.
- Optional Walmart Marketplace catalog adapter for eligible accounts.
- Honest fallback searches for sources that do not have a configured/appropriate API.
- Browser-based coupon verification engine for Shopify, WooCommerce, and generic coupon forms.
- Coupon code cleanup/deduplication, max-code limits, request throttling, challenge detection, and stop-after-success mode.
- Coupon results are `verified`, `failed`, `unknown`, or `challenge`. Unknown is never promoted to verified.
- No CAPTCHA/WAF bypass and no fake prices or fake coupon success.
- Worker secrets stay server-side. Optional `PROWLER_API_TOKEN` protects a public worker.
- GitHub Pages front end stores only worker URL/token and shopping-list data locally on the device.

## GitHub
Upload this repository as-is. The included `.github/workflows/deploy-promoprowler-v11.yml` syntax-checks/tests and deploys the static front end to Pages.

## Worker
The live adapters and coupon tester need the `worker/` service running on a Docker/Python host.
`worker/render.yaml` is included as a deployment blueprint. Other Docker hosts work too.

Set the deployed HTTPS worker URL in PromoProwler once. If `PROWLER_API_TOKEN` is configured on the worker, enter the same token in the front end; it is stored only in that browser's localStorage.

## Credentials
Copy `worker/.env.example` and set only the credentials you actually have. Never commit secrets.

eBay uses its Browse API. Walmart Marketplace requires eligible developer credentials/onboarding. Sources without a suitable configured API remain exact search fallbacks instead of being scraped or fabricated.

## Promo testing
The worker uses a fresh browser session, attempts a normal add-to-cart flow, detects Shopify/WooCommerce/generic coupon forms, tests deduplicated codes with a delay, compares before/after totals when available, and records the retailer's evidence. If a CAPTCHA/security challenge appears, it stops and reports `challenge`; it does not evade it. It never submits the final purchase.

## v12 merge additions
- Checkout Queue with per-item matching (fixes the old global-cheapest assignment bug).
- Quantity, preferred vendor, checked shopping-list items.
- Worker results with real prices are saved as offers for later assignment.
- Manual verified offer capture retained; unknown shipping/tax stays incomplete.
- Local-stock/pickup launch routes.
- Worker search now honors a bounded `limit` parameter.
- Existing v11 live adapters and promo verification engine remain connected.
