import os, time
from collections import defaultdict, deque
from flask import Flask, request, jsonify
from flask_cors import CORS
from urllib.parse import quote_plus
from core import sort_offers
from adapters import ebay, walmart
from promo_engine import test_codes
import asyncio

app=Flask(__name__)
allowed=os.getenv("PROWLER_ALLOWED_ORIGINS","*")
CORS(app, origins="*" if allowed=="*" else [x.strip() for x in allowed.split(",") if x.strip()])

FALLBACK=[
 ("Google Shopping","https://www.google.com/search?tbm=shop&q="),
 ("Walmart","https://www.walmart.com/search?q="),("Home Depot","https://www.homedepot.com/s/"),
 ("Lowe's","https://www.lowes.com/search?searchTerm="),("eBay","https://www.ebay.com/sch/i.html?_nkw="),
 ("Amazon","https://www.amazon.com/s?k="),("Target","https://www.target.com/s?searchTerm="),
 ("Best Buy","https://www.bestbuy.com/site/searchpage.jsp?st="),("Ace","https://www.acehardware.com/search?query="),
 ("Menards","https://www.menards.com/main/search.html?search="),("Tractor Supply","https://www.tractorsupply.com/tsc/search/"),
 ("Harbor Freight","https://www.harborfreight.com/search?q=")
]
RATE=defaultdict(deque)

def require_token():
    wanted=os.getenv("PROWLER_API_TOKEN","")
    if not wanted:return None
    auth=request.headers.get("Authorization","")
    if auth!="Bearer "+wanted:return (jsonify(error="unauthorized"),401)
    return None

def limited(bucket, max_calls, seconds=60):
    ip=request.headers.get("X-Forwarded-For",request.remote_addr or "unknown").split(",")[0].strip()
    key=(ip,bucket); now=time.time(); q=RATE[key]
    while q and q[0]<now-seconds:q.popleft()
    if len(q)>=max_calls:return True
    q.append(now); return False

@app.before_request
def auth():
    if request.path=="/health":return None
    return require_token()

@app.get("/health")
def health():
    search_adapters=[]
    if ebay.configured():search_adapters.append("eBay Browse API")
    if walmart.configured():search_adapters.append("Walmart Marketplace API")
    return jsonify(ok=True,service="promoprowler-worker-v12",
                   search_adapters=search_adapters,promo_engines=["Shopify","WooCommerce","generic coupon-form"],
                   captcha_bypass=False)

@app.get("/api/search")
def search():
    if limited("search",30):return jsonify(error="rate limit"),429
    q=request.args.get("q","").strip(); scope=request.args.get("scope","all"); z=request.args.get("zip","").strip(); limit=max(1,min(int(request.args.get("limit","20")),40))
    if not q:return jsonify(error="q required"),400
    results=[]; used=[]; errors=[]
    adapters=[("eBay",ebay),("Walmart",walmart)]
    for name,mod in adapters:
        if not mod.configured():continue
        try:
            got=mod.search(q,z,limit); results.extend(got); used.append(name)
        except Exception as e:
            errors.append({"adapter":name,"error":str(e)[:180]})
    # Never manufacture a price. If no live item came from an adapter, give navigable source records.
    if not results:
        for name,url in FALLBACK:
            results.append({"merchant":name,"title":q,"url":url+quote_plus(q),"price":None,"shipping":None,
                            "tax":None,"savings":0,"known_total":None,"total":None,"complete":False,
                            "status":"fallback-search","source":"navigation"})
    return jsonify(query=q,results=sort_offers(results),adapters_used=used,adapter_errors=errors)

@app.post("/api/promos/test")
def promos():
    if limited("promo",8):return jsonify(error="promo rate limit"),429
    d=request.get_json(silent=True) or {}
    merchant=str(d.get("merchant","")).strip(); product_url=str(d.get("product_url","")).strip()
    codes=d.get("codes") or []
    if not merchant or not product_url or not codes:return jsonify(error="merchant, product_url and codes required"),400
    max_codes=max(1,min(int(d.get("max_codes") or 20),40))
    stop=bool(d.get("stop_after_success"))
    try:
        result=asyncio.run(test_codes(merchant,product_url,codes,max_codes,stop))
        status=503 if result.get("error") and result.get("engine")=="browser-unavailable" else 200
        return jsonify(result),status
    except Exception as e:
        return jsonify(error="promo engine failed",detail=str(e)[:240]),500

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","8787")))
