import os, time, base64, requests
from core import normalize_offer

TOKEN=None; TOKEN_EXP=0

def configured():
    return bool(os.getenv("EBAY_CLIENT_ID") and os.getenv("EBAY_CLIENT_SECRET"))

def _token():
    global TOKEN,TOKEN_EXP
    now=time.time()
    if TOKEN and now<TOKEN_EXP-60:return TOKEN
    cid=os.environ["EBAY_CLIENT_ID"]; secret=os.environ["EBAY_CLIENT_SECRET"]
    auth=base64.b64encode(f"{cid}:{secret}".encode()).decode()
    r=requests.post("https://api.ebay.com/identity/v1/oauth2/token",
        headers={"Authorization":"Basic "+auth,"Content-Type":"application/x-www-form-urlencoded"},
        data={"grant_type":"client_credentials","scope":"https://api.ebay.com/oauth/api_scope"},timeout=20)
    r.raise_for_status(); d=r.json(); TOKEN=d["access_token"]; TOKEN_EXP=now+int(d.get("expires_in",7200)); return TOKEN

def search(query, zip_code="", limit=20):
    if not configured(): return []
    r=requests.get("https://api.ebay.com/buy/browse/v1/item_summary/search",
        headers={"Authorization":"Bearer "+_token(),"X-EBAY-C-MARKETPLACE-ID":"EBAY_US"},
        params={"q":query,"limit":min(limit,50)},timeout=25)
    r.raise_for_status(); data=r.json(); out=[]
    for x in data.get("itemSummaries",[]):
        p=(x.get("price") or {}).get("value")
        ship=None
        opts=x.get("shippingOptions") or []
        if opts: ship=(opts[0].get("shippingCost") or {}).get("value")
        out.append(normalize_offer("eBay",x.get("title"),x.get("itemWebUrl") or x.get("itemHref"),
                                   p,ship,None,0,"pre-tax","ebay-browse-api"))
    return out
