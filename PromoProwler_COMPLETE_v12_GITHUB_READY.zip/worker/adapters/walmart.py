import os, time, base64, uuid, requests
from urllib.parse import quote_plus
from core import normalize_offer

TOKEN=None; TOKEN_EXP=0

def configured():
    return bool(os.getenv("WALMART_CLIENT_ID") and os.getenv("WALMART_CLIENT_SECRET"))

def _token():
    global TOKEN,TOKEN_EXP
    now=time.time()
    if TOKEN and now<TOKEN_EXP-60:return TOKEN
    raw=f"{os.environ['WALMART_CLIENT_ID']}:{os.environ['WALMART_CLIENT_SECRET']}".encode()
    auth=base64.b64encode(raw).decode()
    r=requests.post("https://marketplace.walmartapis.com/v3/token",
        headers={"Authorization":"Basic "+auth,"Accept":"application/json","Content-Type":"application/x-www-form-urlencoded"},
        data={"grant_type":"client_credentials"},timeout=20)
    r.raise_for_status(); d=r.json(); TOKEN=d.get("access_token"); TOKEN_EXP=now+int(d.get("expires_in",900)); return TOKEN

def search(query, zip_code="", limit=20):
    if not configured(): return []
    headers={
        "WM_SEC.ACCESS_TOKEN":_token(),
        "WM_QOS.CORRELATION_ID":str(uuid.uuid4()),
        "WM_SVC.NAME":"Walmart Marketplace",
        "Accept":"application/json"
    }
    ch=os.getenv("WALMART_CHANNEL_TYPE")
    if ch: headers["WM_CONSUMER.CHANNEL.TYPE"]=ch
    r=requests.get("https://marketplace.walmartapis.com/v3/items/walmart/search",
        headers=headers,params={"query":query,"responseFormat":"DEFAULT"},timeout=25)
    r.raise_for_status(); data=r.json(); out=[]
    for x in (data.get("items") or [])[:limit]:
        item_id=x.get("itemId")
        url=f"https://www.walmart.com/ip/{item_id}" if item_id else "https://www.walmart.com/search?q="+quote_plus(query)
        out.append(normalize_offer("Walmart",x.get("title") or x.get("productName"),url,
                                   x.get("price"),None,None,0,"catalog-price / shipping unknown","walmart-marketplace-api"))
    return out
