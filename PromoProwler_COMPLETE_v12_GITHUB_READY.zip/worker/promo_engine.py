import asyncio, re, time
from urllib.parse import urlparse, urljoin, quote
from core import clean_codes, contains_challenge

BAD_WORDS=("invalid","not valid","isn't valid","not available","not applicable","expired","already used","couldn’t find","couldn't find","not recognized")
GOOD_WORDS=("applied","discount code","coupon code applied","coupon applied","promotion applied","you saved")

def detect_platform(html, url=""):
    s=(html or "").lower(); h=(urlparse(url).hostname or "").lower()
    if "cdn.shopify.com" in s or "shopify" in s or "/products/" in url:return "shopify"
    if "woocommerce" in s or "wc-block" in s or "woocommerce-cart" in s:return "woocommerce"
    return "generic"

def _money_from_text(text):
    nums=re.findall(r"(?:\$|USD\s*)\s*([0-9][0-9,]*(?:\.[0-9]{2})?)",text or "",re.I)
    if not nums:return None
    try:return float(nums[-1].replace(",",""))
    except:return None

async def _challenge(page):
    try:
        txt=(await page.locator("body").inner_text(timeout=3500))[:30000]
        return contains_challenge(txt)
    except:return False

async def _body(page):
    try:return (await page.locator("body").inner_text(timeout=5000))[:50000]
    except:return ""

async def _cart_total(page):
    selectors=[
        "[data-checkout-payment-due-target]","[data-order-summary-section='payment-lines']",
        ".order-total .amount",".cart-subtotal .amount",".total-line__price",".payment-due__price",
        "[class*='total'] [class*='price']"
    ]
    for s in selectors:
        try:
            loc=page.locator(s).last
            if await loc.count():
                v=_money_from_text(await loc.inner_text(timeout=1200))
                if v is not None:return v
        except:pass
    return _money_from_text(await _body(page))

async def _click_first(page, selectors):
    for s in selectors:
        try:
            loc=page.locator(s).first
            if await loc.count() and await loc.is_visible():
                await loc.click(timeout=3500); return True
        except:pass
    return False

async def _fill_first(page, selectors, value):
    for s in selectors:
        try:
            loc=page.locator(s).first
            if await loc.count() and await loc.is_visible():
                await loc.fill(value,timeout=3000); return True
        except:pass
    return False

async def _prepare_cart(page, product_url, platform):
    await page.goto(product_url,wait_until="domcontentloaded",timeout=30000)
    if await _challenge(page):return False,"challenge"
    if platform=="shopify" or platform=="generic":
        ok=await _click_first(page,["form[action*='/cart/add'] button[type='submit']","button[name='add']","button[id*='AddToCart']","button:has-text('Add to cart')"])
        if ok:
            await page.wait_for_timeout(1400)
            return True,"clicked add-to-cart"
    if platform=="woocommerce" or platform=="generic":
        ok=await _click_first(page,["button.single_add_to_cart_button","button[name='add-to-cart']","button:has-text('Add to cart')"])
        if ok:
            await page.wait_for_timeout(1400)
            return True,"clicked add-to-cart"
    return True,"cart preparation not confirmed"

async def _test_woo(page, origin, code):
    await page.goto(urljoin(origin,"/cart/"),wait_until="domcontentloaded",timeout=30000)
    if await _challenge(page):return {"code":code,"status":"challenge","evidence":"retailer challenge detected"}
    before=await _cart_total(page)
    ok=await _fill_first(page,["input[name='coupon_code']","input#coupon_code","input[placeholder*='coupon' i]"],code)
    if not ok:return {"code":code,"status":"unknown","before":before,"evidence":"coupon field not found"}
    await _click_first(page,["button[name='apply_coupon']","button:has-text('Apply coupon')","button:has-text('Apply')"])
    await page.wait_for_timeout(1700); body=(await _body(page)).lower(); after=await _cart_total(page)
    if await _challenge(page):return {"code":code,"status":"challenge","before":before,"evidence":"retailer challenge detected"}
    if any(w in body for w in BAD_WORDS):status="failed"; ev="store rejected code"
    elif (before is not None and after is not None and after < before) or ("coupon" in body and "applied" in body):status="verified"; ev="store accepted code / cart total changed"
    else:status="unknown"; ev="no conclusive accept/reject evidence"
    return {"code":code,"status":status,"before":before,"after":after,"savings":round(before-after,2) if before is not None and after is not None and after<before else None,"evidence":ev}

async def _test_shopify(page, origin, code):
    # Shopify's public /discount/CODE path applies a code to the current storefront session.
    before=None
    try:
        await page.goto(urljoin(origin,"/checkout"),wait_until="domcontentloaded",timeout=30000)
        before=await _cart_total(page)
    except:pass
    target=urljoin(origin,"/discount/"+quote(code,safe="")+"?redirect=/checkout")
    await page.goto(target,wait_until="domcontentloaded",timeout=30000); await page.wait_for_timeout(1200)
    body=(await _body(page)).lower(); after=await _cart_total(page)
    if await _challenge(page):return {"code":code,"status":"challenge","before":before,"evidence":"retailer challenge detected"}
    if any(w in body for w in BAD_WORDS):status="failed"; ev="store rejected code"
    else:
        code_seen=code.lower() in body
        saved=(before is not None and after is not None and after < before)
        success_word=any(w in body for w in GOOD_WORDS)
        if saved or (code_seen and success_word):status="verified"; ev="discount shown in checkout / total decreased"
        else:status="unknown"; ev="checkout did not provide conclusive evidence"
    return {"code":code,"status":status,"before":before,"after":after,"savings":round(before-after,2) if before is not None and after is not None and after<before else None,"evidence":ev}

async def test_codes(merchant, product_url, codes, max_codes=20, stop_after_success=False):
    codes=clean_codes(codes,min(max(int(max_codes or 20),1),40))
    try:
        from playwright.async_api import async_playwright
    except Exception:
        return {"engine":"browser-unavailable","challenge":False,"results":[],"error":"Playwright/browser is not installed in this worker."}
    origin=f"{urlparse(product_url).scheme}://{urlparse(product_url).netloc}"
    results=[]; challenge=False
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True,args=["--disable-dev-shm-usage"])
        ctx=await browser.new_context(viewport={"width":1280,"height":900},locale="en-US")
        page=await ctx.new_page()
        await page.goto(product_url,wait_until="domcontentloaded",timeout=30000)
        html=await page.content(); platform=detect_platform(html,product_url)
        ok,prep=await _prepare_cart(page,product_url,platform)
        if prep=="challenge":
            await browser.close(); return {"engine":platform,"challenge":True,"results":[],"error":"Retailer challenge detected before testing."}
        for code in codes:
            if platform=="woocommerce":r=await _test_woo(page,origin,code)
            elif platform=="shopify":r=await _test_shopify(page,origin,code)
            else:
                # Generic safe attempt: detect common coupon UI on cart page.
                r=await _test_woo(page,origin,code)
            results.append(r)
            if r.get("status")=="challenge":challenge=True; break
            if stop_after_success and r.get("status")=="verified":break
            await page.wait_for_timeout(900)
        await browser.close()
    return {"engine":platform,"challenge":challenge,"results":results,"prepared":prep}
