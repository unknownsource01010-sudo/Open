import re
from decimal import Decimal, InvalidOperation
from urllib.parse import urlparse

CODE_RE = re.compile(r"^[A-Z0-9_-]{2,32}$")
CHALLENGE_MARKERS = (
    "captcha","recaptcha","hcaptcha","verify you are human","are you human",
    "cloudflare","access denied","unusual traffic","security challenge","bot detection"
)

def clean_codes(values, limit=40):
    out=[]; seen=set()
    for raw in values or []:
        for part in re.split(r"[\s,;]+", str(raw).strip()):
            code=part.strip().upper()
            if code and CODE_RE.match(code) and code not in seen:
                seen.add(code); out.append(code)
                if len(out)>=limit: return out
    return out

def money(value):
    if value is None or value == "": return None
    try: return float(Decimal(str(value).replace("$","").replace(",","").strip()))
    except (InvalidOperation, ValueError): return None

def contains_challenge(text):
    s=(text or "").lower()
    return any(x in s for x in CHALLENGE_MARKERS)

def host_of(url):
    try: return (urlparse(url).hostname or "").lower()
    except Exception: return ""

def normalize_offer(merchant,title,url,price=None,shipping=None,tax=None,savings=0,status="live",source="adapter"):
    price=money(price); shipping=money(shipping); tax=money(tax); savings=money(savings) or 0.0
    known_total=None
    if price is not None:
        known_total=price + (shipping or 0.0) - savings
    complete = price is not None and shipping is not None and tax is not None
    final_total=(price+shipping+tax-savings) if complete else None
    return {
        "merchant":merchant,"title":title or "Untitled","url":url,
        "price":price,"shipping":shipping,"tax":tax,"savings":savings,
        "known_total":round(known_total,2) if known_total is not None else None,
        "total":round(final_total,2) if final_total is not None else None,
        "complete":bool(complete),"status":status if not complete else "complete","source":source
    }

def sort_offers(items):
    return sorted(items, key=lambda x:(
        0 if x.get("complete") else 1,
        x.get("known_total") if x.get("known_total") is not None else 10**18,
        x.get("merchant","")
    ))
